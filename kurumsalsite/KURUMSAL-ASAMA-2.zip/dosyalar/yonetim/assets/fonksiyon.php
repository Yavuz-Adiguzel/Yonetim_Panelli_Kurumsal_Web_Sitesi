<?php ob_start();
		try {
$baglanti=new PDO("mysql:host=localhost;dbname=kurumsal;charset=utf8","root","");
$baglanti->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);  	

}catch(PDOException $e) {
	die($e->getMessage());
}

class yonetim {

	function sorgum($vt,$sorgu,$tercih=0) {

	$al=$vt->prepare($sorgu);
	$al->execute();

	if ($tercih==1) :
	return $al->fetch();

	elseif ($tercih==2):
	return $al;
    endif;


	}


function siteayar($baglanti){

	$sonuc=$this->sorgum($baglanti,"select * from ayarlar",1);

	if($_POST) :

    $title=htmlspecialchars($_POST["title"]);
    $metatitle=htmlspecialchars($_POST["metatitle"]);
    $metadesc=htmlspecialchars($_POST["metadesc"]);
    $metakey=htmlspecialchars($_POST["metakey"]);
    $metaauthor=htmlspecialchars($_POST["metaauthor"]);
    $metaowner=htmlspecialchars($_POST["metaowner"]);
    $metacopy=htmlspecialchars($_POST["metacopy"]);
    $logoyazi=htmlspecialchars($_POST["logoyazi"]);
    $twit=htmlspecialchars($_POST["twit"]);
    $face=htmlspecialchars($_POST["face"]);
    $inst=htmlspecialchars($_POST["inst"]);
    $telefonno=htmlspecialchars($_POST["telefonno"]);
    $adres=htmlspecialchars($_POST["adres"]);
    $mailadres=htmlspecialchars($_POST["mailadres"]);
    $slogan=htmlspecialchars($_POST["slogan"]);
    $referansbaslik=htmlspecialchars($_POST["refsayfabas"]);
    $filobaslik=htmlspecialchars($_POST["filosayfabas"]);
    $yorumbaslik=htmlspecialchars($_POST["yorumsayfabas"]);
    $iletisimbaslik=htmlspecialchars($_POST["iletisimsayfabas"]);

//burda bunların boş veya doluluk kontrolü yapılabilir.
//burada veritabanı 

    $guncelleme=$baglanti->prepare("update ayarlar set
     title=?,metatitle=?,metadesc=?,metakey=?,metaauthor=?,metaowner=?,metacopy=?,logoyazisi=?,twit=?,face=?,inst=?,telefonno=?,adres=?,mailadres=?,slogan=?,referansbaslik=?,filobaslik=?,yorumbaslik=?,iletisimbaslik=?");

      $guncelleme->bindParam(1,$title,PDO::PARAM_STR);
      $guncelleme->bindParam(2,$metatitle,PDO::PARAM_STR);
      $guncelleme->bindParam(3,$metadesc,PDO::PARAM_STR);
      $guncelleme->bindParam(4,$metakey,PDO::PARAM_STR);
      $guncelleme->bindParam(5,$metaauthor,PDO::PARAM_STR);
      $guncelleme->bindParam(6,$metaowner,PDO::PARAM_STR);
      $guncelleme->bindParam(7,$metacopy,PDO::PARAM_STR);
      $guncelleme->bindParam(8,$logoyazi,PDO::PARAM_STR);
      $guncelleme->bindParam(9,$twit,PDO::PARAM_STR);
      $guncelleme->bindParam(10,$face,PDO::PARAM_STR);
      $guncelleme->bindParam(11,$inst,PDO::PARAM_STR);
      $guncelleme->bindParam(12,$telefonno,PDO::PARAM_STR);
      $guncelleme->bindParam(13,$adres,PDO::PARAM_STR);
      $guncelleme->bindParam(14,$mailadres,PDO::PARAM_STR);
      $guncelleme->bindParam(15,$slogan,PDO::PARAM_STR);
      $guncelleme->bindParam(16,$referansbaslik,PDO::PARAM_STR);
      $guncelleme->bindParam(17,$filobaslik,PDO::PARAM_STR);
      $guncelleme->bindParam(18,$yorumbaslik,PDO::PARAM_STR);
      $guncelleme->bindParam(19,$iletisimbaslik,PDO::PARAM_STR);
      $guncelleme->execute();


      echo '<div class="alert alert-success" role="alert">
      <strong>SİTE AYARLARI</strong> BAŞARIYLA GÜNCELLENDİ.

      </div>';

      header("refresh:2,url=control.php");




	else :

	?>

	<form action="control.php?sayfa=siteayar" method="post">

                        <div class="row">

                            <div class="col-lg-8 mx-auto mt-2">
                                <h3 class="text-danger">SİTE AYARLARI</h3>
                            </div>
                            
                            <div class="col-lg-8 mx-auto mt-2 border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>TİTLE</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="title" class="form-control" value="<?php echo $sonuc["title"]; ?>" /></div>
                               </div>
                                   
                            </div>
                           <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>META TİTLE</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="metatitle" class="form-control" value="<?php echo $sonuc["metatitle"]; ?>" /></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->
                             <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>SAYFA AÇIKLAMASI</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="metadesc" class="form-control"value="<?php echo $sonuc["metadesc"]; ?>"/></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->
                             <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>ANAHTAR KELİMELER</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="metakey" class="form-control"value="<?php echo $sonuc["metakey"]; ?>"/></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->
                             <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>YAPIMCI</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="metaauthor" class="form-control"value="<?php echo $sonuc["metaauthor"]; ?>"/></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->
                             <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>FİRMA</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="metaowner" class="form-control"value="<?php echo $sonuc["metaowner"]; ?>"/></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->
                             <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>COPYRIGHT</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="metacopy" class="form-control"value="<?php echo $sonuc["metacopy"]; ?>"/></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->
                             <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>LOGO YAZISI</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="logoyazi" class="form-control"value="<?php echo $sonuc["logoyazisi"]; ?>"/></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->
                             <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>TWITTER</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="twit" class="form-control"value="<?php echo $sonuc["twit"]; ?>"/></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->
                             <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>FACEBOOK</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="face" class="form-control" value="<?php echo $sonuc["face"]; ?>"/></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->
                             <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>INSTAGRAM</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="inst" class="form-control" value="<?php echo $sonuc["inst"]; ?>"/></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->
                             <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>TELEFON NUMARASI</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="telefonno" class="form-control" value="<?php echo $sonuc["telefonno"]; ?>"/></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->
                             <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>ADRES</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="adres" class="form-control" value="<?php echo $sonuc["adres"]; ?>"/></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->
                             <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>MAIL ADRESİ</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="mailadres" class="form-control" value="<?php echo $sonuc["mailadres"]; ?>"/></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->
                             <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>SLOGAN</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="slogan" class="form-control" value="<?php echo $sonuc["slogan"]; ?>"/></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->
                             <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>REFERANS SAYFA BAŞLIĞI</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="refsayfabas" class="form-control" value="<?php echo $sonuc["referansbaslik"]; ?>"/></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->
                             <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>FİLO SAYFA BAŞLIĞI</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="filosayfabas" class="form-control" value="<?php echo $sonuc["filobaslik"]; ?>"/></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->
                            <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>YORUM SAYFA BAŞLIĞI</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="yorumsayfabas" class="form-control" value="<?php echo $sonuc["yorumbaslik"]; ?>"/></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->
                            <!-- ******************* -->
                            <div class="col-lg-8 mx-auto border">
                                <div class="row"><div class="col-lg-6 border-right p-2"><span>İLETİŞİM SAYFA BAŞLIĞI</span></div>
                                   <div class="col-lg-6 p-2"><input type="text" name="iletisimsayfabas" class="form-control" value="<?php echo $sonuc["yorumbaslik"]; ?>"/></div>
                               </div>
                                   
                            </div>

                            <!-- ******************* -->

                            <div class="col-lg-8 mx-auto mt-2 border-bottom">
                                <input type="submit" name="buton" class="btn btn-danger m-1" value="GÜNCELLE" />
                            </div>

                        </div>


                         </form>

	<?php

	endif;	

}


//Şifrele
function sifrele($veri){
  return base64_encode(gzdeflate(gzcompress(serialize($veri))));

}
//Çöz
function coz($veri){
  return unserialize(gzuncompress(gzinflate(base64_decode($veri))));
}
//Kullanıcı Adını alıyoruz
function kuladial($vt){

  $cookid=$_COOKIE["kulbilgi"];

  $cozduk=self::coz($cookid);

  $sorgusonuc=self::sorgum($vt,"select * from yonetim where id=$cozduk",1);

  return $sorgusonuc["kulad"];

}

//Giriş kontrol

function giriskontrol ($kulad,$sifre,$vt) {

  $sifrelihal=md5(sha1(md5($sifre)));

  $sor=$vt->prepare("select * from yonetim where kulad='$kulad' and sifre='$sifrelihal'");
  $sor->execute();

  if ($sor->rowCount()==0):

    echo '<div class="container-fluid bg-white">
            <div class="alert alert-white border border-dark mt-5 col-md-5 mx-auto text-danger font-14 font-weight-bold"><img src="loader.gif" class="mr-3">BİLGİLER HATALI !!!</div>
            </div>';

            header("refresh:2,url=index.php");

          else:
            $gelendeger=$sor->fetch();
            $sor=$vt->prepare("update yonetim set aktif=1 where kulad='$kulad' and sifre='$sifrelihal'");
  $sor->execute();

  echo '<div class="container-fluid bg-white">
            <div class="alert alert-white border border-dark mt-5 col-md-5 mx-auto text-success font-14 font-weight-bold"><img src="loader.gif" class="mr-3">GİRİŞ YAPILIYOR...</div>
            </div>';

            header("refresh:2,url=control.php");

            //cookie
            $id=self::sifrele($gelendeger["id"]);
            setcookie("kulbilgi",$id, time() + 60*60*24); 

  endif;

}
//Çıkış
function cikis($vt){

  $cookid=$_COOKIE["kulbilgi"];

  $cozduk=self::coz($cookid);

  self::sorgum($vt,"update yonetim set aktif=0 where id=$cozduk",0);

  setcookie("kulbilgi",$cookid, time() - 5);

  echo '<div class="container-fluid bg-white">
            <div class="alert alert-white border border-dark mt-5 col-md-5 mx-auto text-info font-14 font-weight-bold"><img src="loader.gif" class="mr-3">ÇIKIŞ YAPILIYOR...</div>
            </div>';

            header("refresh:2,url=index.php");

}

function kontrolet($sayfa){

  if (isset($_COOKIE["kulbilgi"])) :

      if ($sayfa=="ind") : header("Location:control.php"); endif;


  else:

      if ($sayfa=="cot") : header("Location:index.php"); endif;
    
  endif;

}

//--------------------İNTRO-----------------------

function introayar($vt){

  echo '<div class="row text-center">
  <div class="col-lg-12 border-bottom"><h3 class="float-left mt-3 text-info">İNTRO RESİMLERİ</h3>
  <a href="control.php?sayfa=introresimekle" class="float-right btn btn-success m-2 ">+</a></div>';
  
  $introbilgiler=self::sorgum($vt,"select * from intro",2);

  while ($sonbilgi=$introbilgiler->fetch(PDO::FETCH_ASSOC)) :

    echo '<div class="col-lg-4">

    <div class="row border border-light p-1 m-1">
    <div class="col-lg-12">
    <img src="../'.$sonbilgi["resimyol"].'">
    </div>

    <div class="col-lg-6 text-right">
    <a href="control.php?sayfa=introresimguncelle&id='.$sonbilgi["id"].'" class="fa fa-edit m-2 text-success" style="font-size:25px;"></a>
    </div>

    <div class="col-lg-6 text-left">
    <a href="control.php?sayfa=introresimsil&id='.$sonbilgi["id"].'" class="fa fa-close m-2 text-danger" style="font-size:25px;"></a>
    </div>

    </div>
</div>';

  endwhile;

  echo '</div>';

}//Mevcut introlar getiriliyor.
//intro resim ekleme
function introresimekleme($vt){

  echo '<div class="row text-center">
  <div class="col-lg-12">
  ';

  if ($_POST) :

    if ( $_FILES["dosya"]["name"]=="") :

      echo '<div class="alert alert-danger mt-1">Dosya Yüklenmedi. Boş Olamaz</div>';
      header("refresh:2,url=control.php?sayfa=introresimekle");  

      else://boş değilse

      if ( $_FILES["dosya"]["size"]> (1024*1024*5)) :

        echo '<div class="alert alert-danger mt-1">Dosya boyutu çok fazla</div>';
        header("refresh:2,url=control.php?sayfa=introresimekle");

        else://boyutta bir problem yok ise

        $izinverilen=array("image/png","image/jpeg");

        if (!in_array ($_FILES["dosya"]["type"],$izinverilen)) :

          echo '<div class="alert alert-danger mt-1">İzin verilen uzantı değil.</div>';
          header("refresh:2,url=control.php?sayfa=introresimekle");

          else://artık herşey tamam

          $dosyaminyolu='../img/carousel/'.$_FILES["dosya"]["name"];

          move_uploaded_file($_FILES["dosya"]["tmp_name"], $dosyaminyolu);

          echo '<div class="alert alert-success mt-1">DOSYA BAŞARIYLA YÜKLENDİ.</div>';
          header("refresh:2,url=control.php?sayfa=introayar");
          //dosya yüklendikten sonra veritabanınada bu kaydı eklemem lazım

          $dosyaminyolu2=str_replace('../','',$dosyaminyolu);

          $kayıtekle=self::sorgum($vt,"insert into intro (resimyol) VALUES('$dosyaminyolu2')",0);      


        endif;

      endif;

    endif;

  else:
    ?>

    <div class="col-lg-4 mx-auto mt-2">
      <div class="card card-bordered">
        <div class="card-body">
          <h5 class="title border-bottom">RESİM YÜKLEME FORMU</h5>
          <form action="" method="post" enctype="multipart/form-data">
            <p class="card-text"><input type="file" name="dosya" /></p>
            <input type="submit" name="buton" value="YÜKLE" class="btn btn-primary mb-1" />
          </form>

          <p class="card-text text-left text-danger border-top">
          * izin verilen formatlar : jgp-png <br/>
          * izin verilen max.boyut : 5 MB
        </p>

      </div>
    </div>
  </div>

    <?php

  endif;

  echo '</div></div></div>';

}
//intro resim silme
function introsil($vt) {

  $introid=$_GET["id"];

  $verial=self::sorgum($vt,"select * from intro where id=$introid",1);

  echo '<div class="row text-center">
  <div class="col-lg-12">
  ';

  //veritabanı ver silme
  self::sorgum($vt,"delete from intro where id=$introid",0);
  //dosyayı silme işlemi
  unlink("../".$verial["resimyol"]);
echo '<div class="alert alert-success mt-1">DOSYA BAŞARIYLA SİLİNDİ.</div>';
  echo '</div></div>';

  header("refresh:2,url=control.php?sayfa=introayar");
}



function introresimguncelleme($vt){

  $gelintroid=$_GET["id"];

  echo '<div class="row text-center">
  <div class="col-lg-12">
  ';

  if ($_POST) :

    $formdangelenid=$_POST["introid"];

    if ( $_FILES["dosya"]["name"]=="") :

      echo '<div class="alert alert-danger mt-1">Dosya Yüklenmedi. Boş Olamaz</div>';
      header("refresh:2,url=control.php?sayfa=introayar");  

      else://boş değilse

      if ( $_FILES["dosya"]["size"]> (1024*1024*5)) :

        echo '<div class="alert alert-danger mt-1">Dosya boyutu çok fazla</div>';
        header("refresh:2,url=control.php?sayfa=introayar");

        else://boyutta bir problem yok ise

        $izinverilen=array("image/png","image/jpeg");

        if (!in_array ($_FILES["dosya"]["type"],$izinverilen)) :

          echo '<div class="alert alert-danger mt-1">İzin verilen uzantı değil.</div>';
          header("refresh:2,url=control.php?sayfa=introayar");

          else://artık herşey tamam


          //db den mevcut veriyi çektik ve dosyayı sildik.
          $resimyolunabak=self::sorgum($vt,"select * from intro where id=$gelintroid",1);
          $dbgelenyol='../'.$resimyolunabak["resimyol"];
          unlink($dbgelenyol);
          //db den mevcut veriyi çektik ve dosyayı sildik.


          $dosyaminyolu='../img/carousel/'.$_FILES["dosya"]["name"];
          move_uploaded_file($_FILES["dosya"]["tmp_name"], $dosyaminyolu);


          $dosyaminyolu2=str_replace('../','',$dosyaminyolu);
          self::sorgum($vt,"update intro set resimyol='$dosyaminyolu2' where id=$gelintroid)",0);


          echo '<div class="alert alert-success mt-1">DOSYA BAŞARIYLA GÜNCELLENDİ.</div>';
          header("refresh:2,url=control.php?sayfa=introayar");

                


        endif;

      endif;

    endif;

  else:
    ?>

    <div class="col-lg-4 mx-auto mt-2">
      <div class="card card-bordered">
        <div class="card-body">
          <h5 class="title border-bottom">RESİM GÜNCELLEME FORMU</h5>
          <form action="" method="post" enctype="multipart/form-data">
            <p class="card-text"><input type="file" name="dosya" /></p>
            <p class="card-text"><input type="hidden" name="introid" value="<?php echo $gelintroid; ?>" /></p>
            <input type="submit" name="buton" value="YÜKLE" class="btn btn-primary mb-1" /> 
          </form>

          <p class="card-text text-left text-danger border-top">
          * izin verilen formatlar : jgp-png <br/>
          * izin verilen max.boyut : 5 MB
        </p>

      </div>
    </div>
  </div>

    <?php

  endif;

  echo '</div></div></div>';

}


//--------------------İNTRO-----------------------

//----------------------ARAÇ FİLOSU------------------------

function filoayar($vt){

  echo '<div class="row text-center">
  <div class="col-lg-12 border-bottom"><h3 class="float-left mt-3 text-info">FİLO RESİMLERİ</h3>
  <a href="control.php?sayfa=filoayarekle" class="float-right btn btn-success m-2 ">+</a></div>';
  
  $introbilgiler=self::sorgum($vt,"select * from filomuz",2);

  while ($sonbilgi=$introbilgiler->fetch(PDO::FETCH_ASSOC)) :

    echo '<div class="col-lg-4">

    <div class="row border border-light p-1 m-1">
    <div class="col-lg-12">
    <img src="../'.$sonbilgi["resimyol"].'">
    </div>

    <div class="col-lg-6 text-right">
    <a href="control.php?sayfa=filoayarguncelleme&id='.$sonbilgi["id"].'" class="fa fa-edit m-2 text-success" style="font-size:25px;"></a>
    </div>

    <div class="col-lg-6 text-left">
    <a href="control.php?sayfa=filoayarsil&id='.$sonbilgi["id"].'" class="fa fa-close m-2 text-danger" style="font-size:25px;"></a>
    </div>

    </div>
</div>';

  endwhile;

  echo '</div>';

}//Mevcut introlar getiriliyor.
//intro resim ekleme
function filoayarekle($vt){

  echo '<div class="row text-center">
  <div class="col-lg-12">
  ';

  if ($_POST) :

    if ( $_FILES["dosya"]["name"]=="") :

      echo '<div class="alert alert-danger mt-1">Dosya Yüklenmedi. Boş Olamaz</div>';
      header("refresh:2,url=control.php?sayfa=filoayarekle");  

      else://boş değilse

      if ( $_FILES["dosya"]["size"]> (1024*1024*5)) :

        echo '<div class="alert alert-danger mt-1">Dosya boyutu çok fazla</div>';
        header("refresh:2,url=control.php?sayfa=filoayarekle");

        else://boyutta bir problem yok ise

        $izinverilen=array("image/png","image/jpeg");

        if (!in_array ($_FILES["dosya"]["type"],$izinverilen)) :

          echo '<div class="alert alert-danger mt-1">İzin verilen uzantı değil.</div>';
          header("refresh:2,url=control.php?sayfa=filoayarekle");

          else://artık herşey tamam

          $dosyaminyolu='../img/filo/'.$_FILES["dosya"]["name"];

          move_uploaded_file($_FILES["dosya"]["tmp_name"], $dosyaminyolu);

          echo '<div class="alert alert-success mt-1">DOSYA BAŞARIYLA YÜKLENDİ.</div>';
          header("refresh:2,url=control.php?sayfa=filoayar");
          //dosya yüklendikten sonra veritabanınada bu kaydı eklemem lazım

          $dosyaminyolu2=str_replace('../','',$dosyaminyolu);

          self::sorgum($vt,"insert into filomuz (resimyol) VALUES('$dosyaminyolu2')",0);      


        endif;

      endif;

    endif;

  else:
    ?>

    <div class="col-lg-4 mx-auto mt-2">
      <div class="card card-bordered">
        <div class="card-body">
          <h5 class="title border-bottom">RESİM YÜKLEME FORMU</h5>
          <form action="" method="post" enctype="multipart/form-data">
            <p class="card-text"><input type="file" name="dosya" /></p>
            <input type="submit" name="buton" value="YÜKLE" class="btn btn-primary mb-1" />
          </form>

          <p class="card-text text-left text-danger border-top">
          * izin verilen formatlar : jgp-png <br/>
          * izin verilen max.boyut : 5 MB
        </p>

      </div>
    </div>
  </div>

    <?php

  endif;

  echo '</div></div></div>';

}
//intro resim silme
function filoayarsil($vt) {

  $introid=$_GET["id"];

  $verial=self::sorgum($vt,"select * from filomuz where id=$introid",1);

  echo '<div class="row text-center">
  <div class="col-lg-12">
  ';

  //veritabanı ver silme
  self::sorgum($vt,"delete from filomuz where id=$introid",0);
  //dosyayı silme işlemi
  unlink("../".$verial["resimyol"]);
echo '<div class="alert alert-success mt-1">DOSYA BAŞARIYLA SİLİNDİ.</div>';
  echo '</div></div>';

  header("refresh:2,url=control.php?sayfa=filoayar");
}



function filoayarguncelleme($vt){

  $gelintroid=$_GET["id"];

  echo '<div class="row text-center">
  <div class="col-lg-12">
  ';

  if ($_POST) :

    $formdangelenid=$_POST["introid"];

    if ( $_FILES["dosya"]["name"]=="") :

      echo '<div class="alert alert-danger mt-1">Dosya Yüklenmedi. Boş Olamaz</div>';
      header("refresh:2,url=control.php?sayfa=filoayar");  

      else://boş değilse

      if ( $_FILES["dosya"]["size"]> (1024*1024*5)) :

        echo '<div class="alert alert-danger mt-1">Dosya boyutu çok fazla</div>';
        header("refresh:2,url=control.php?sayfa=filoayar");

        else://boyutta bir problem yok ise

        $izinverilen=array("image/png","image/jpeg");

        if (!in_array ($_FILES["dosya"]["type"],$izinverilen)) :

          echo '<div class="alert alert-danger mt-1">İzin verilen uzantı değil.</div>';
          header("refresh:2,url=control.php?sayfa=filoayar");

          else://artık herşey tamam


          //db den mevcut veriyi çektik ve dosyayı sildik.
          $resimyolunabak=self::sorgum($vt,"select * from filomuz where id=$gelintroid",1);
          $dbgelenyol='../'.$resimyolunabak["resimyol"];
          unlink($dbgelenyol);
          //db den mevcut veriyi çektik ve dosyayı sildik.


          $dosyaminyolu='../img/filo/'.$_FILES["dosya"]["name"];
          move_uploaded_file($_FILES["dosya"]["tmp_name"], $dosyaminyolu);


          $dosyaminyolu2=str_replace('../','',$dosyaminyolu);
          self::sorgum($vt,"update filomuz set resimyol='$dosyaminyolu2' where id=$gelintroid)",0);


          echo '<div class="alert alert-success mt-1">DOSYA BAŞARIYLA GÜNCELLENDİ.</div>';
          header("refresh:2,url=control.php?sayfa=filoayar");

                


        endif;

      endif;

    endif;

  else:
    ?>

    <div class="col-lg-4 mx-auto mt-2">
      <div class="card card-bordered">
        <div class="card-body">
          <h5 class="title border-bottom">RESİM GÜNCELLEME FORMU</h5>
          <form action="" method="post" enctype="multipart/form-data">
            <p class="card-text"><input type="file" name="dosya" /></p>
            <p class="card-text"><input type="hidden" name="introid" value="<?php echo $gelintroid; ?>" /></p>
            <input type="submit" name="buton" value="YÜKLE" class="btn btn-primary mb-1" /> 
          </form>

          <p class="card-text text-left text-danger border-top">
          * izin verilen formatlar : jgp-png <br/>
          * izin verilen max.boyut : 5 MB
        </p>

      </div>
    </div>
  </div>

    <?php

  endif;

  echo '</div></div></div>';

}


//----------------------ARAÇ FİLOSU------------------------

//-----------------HAKKIMIZDA------------------------

function hakkimizda($vt){

  echo '<div class="row text-center">
  <div class="col-lg-12 border-bottom"><h3 class="mt-3 text-info">HAKKIMIZDA AYARLARI</h3></div>';

  if (!$_POST) :



  
  $sonbilgi=self::sorgum($vt,"select * from hakkimizda",1);


    echo '<div class="col-lg-6 mx-auto">

    <div class="row border border-light p-1 m-1">


    <div class="col-lg-3 border-bottom bg-light" id="hakkimizdayazilar">
    Resim
    </div>

    <div class="col-lg-9 border-bottom">
    <img src="../'.$sonbilgi["resim"].'"><br>
    <form action="" method="post" enctype="multipart/form-data">
    <input type="file" name="dosya">
    </div>

    <div class="col-lg-3 border-bottom bg-light pt-3" id="hakkimizdayazilarn">
    Başlık
    </div>

    <div class="col-lg-9 border-bottom">
    <input type="text" name="baslik" class="form-control m-2" value="'.$sonbilgi["baslik"].'">
    </div>

    <div class="col-lg-3 bg-light" id="hakkimizdayazilar">
    İçerik
    </div>

    <div class="col-lg-9">
    <textarea name="icerik" class="form-control" rows="8">'.$sonbilgi["icerik"].'</textarea>
    </div>

    <div class="col-lg-12 border-top">
    <input type="submit" name="guncel" value="GÜNCELLE" class="btn btn-primary m-2">
    </form>
    </div>
    </div>';

else:

$baslik=$_POST["baslik"];
$icerik=$_POST["icerik"];
  //form Başladıysa


if (@$_FILES["dosya"]["name"]!="") :



      if ( $_FILES["dosya"]["size"]< (1024*1024*5)) :



        $izinverilen=array("image/png","image/jpeg");

        if (in_array ($_FILES["dosya"]["type"],$izinverilen)) :


          $dosyaminyolu='../img/'.$_FILES["dosya"]["name"];

          move_uploaded_file($_FILES["dosya"]["tmp_name"], $dosyaminyolu);


          $veritabaniicin=str_replace('../','',$dosyaminyolu);


      endif;
   endif;
endif;

if ( @$_FILES["dosya"]["name"]!="") :
  self::sorgum($vt,"update hakkimizda set baslik='$baslik',icerik='$icerik',resim='$veritabaniicin'",0);

  echo '
  <div class="col-lg-6 mx-auto">
  <div class="alert alert-success mt-1">GÜNCELLEME BAŞARILI.
  </div>
  ';
  echo '</div></div>';

  header("refresh:2,url=control.php?sayfa=hakkimizayar");

else:

  echo '<div class="alert alert-success mt-1">GÜNCELLEME BAŞARILI.</div>';
  echo '</div></div>';

  header("refresh:2,url=control.php?sayfa=hakkimizayar");

  self::sorgum($vt,"update hakkimizda set baslik='$baslik',icerik='$icerik'",0);

  echo '
  <div class="col-lg-6 mx-auto">
  <div class="alert alert-success mt-1">GÜNCELLEME BAŞARILI.
  </div>
  ';

endif;



echo '</div>';

endif;//en ana if

}



}


?>