-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 29 Haz 2019, 13:18:25
-- Sunucu sürümü: 5.7.23
-- PHP Sürümü: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `ogrenci`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ayarlar`
--

DROP TABLE IF EXISTS `ayarlar`;
CREATE TABLE IF NOT EXISTS `ayarlar` (
  `id` int(11) NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `metatitle` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `metadesc` text COLLATE utf8mb4_turkish_ci NOT NULL,
  `metakey` text COLLATE utf8mb4_turkish_ci NOT NULL,
  `metaauthor` varchar(40) COLLATE utf8mb4_turkish_ci NOT NULL,
  `metaowner` varchar(40) COLLATE utf8mb4_turkish_ci NOT NULL,
  `metacopy` varchar(40) COLLATE utf8mb4_turkish_ci NOT NULL,
  `logoyazisi` varchar(40) COLLATE utf8mb4_turkish_ci NOT NULL,
  `twit` varchar(70) COLLATE utf8mb4_turkish_ci NOT NULL,
  `face` varchar(70) COLLATE utf8mb4_turkish_ci NOT NULL,
  `inst` varchar(70) COLLATE utf8mb4_turkish_ci NOT NULL,
  `telefonno` varchar(25) COLLATE utf8mb4_turkish_ci NOT NULL,
  `adres` varchar(150) COLLATE utf8mb4_turkish_ci NOT NULL,
  `mailadres` varchar(30) COLLATE utf8mb4_turkish_ci NOT NULL,
  `slogan` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `referansbaslik` text COLLATE utf8mb4_turkish_ci NOT NULL,
  `filobaslik` text COLLATE utf8mb4_turkish_ci NOT NULL,
  `yorumbaslik` text COLLATE utf8mb4_turkish_ci NOT NULL,
  `iletisimbaslik` text COLLATE utf8mb4_turkish_ci NOT NULL,
  `hizmetlerbaslik` varchar(100) COLLATE utf8mb4_turkish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `ayarlar`
--

INSERT INTO `ayarlar` (`id`, `title`, `metatitle`, `metadesc`, `metakey`, `metaauthor`, `metaowner`, `metacopy`, `logoyazisi`, `twit`, `face`, `inst`, `telefonno`, `adres`, `mailadres`, `slogan`, `referansbaslik`, `filobaslik`, `yorumbaslik`, `iletisimbaslik`, `hizmetlerbaslik`) VALUES
(0, 'Burhan Dayıoğlu', 'Burhan Dayıoğlu', 'Burhan Dayıoğlu', 'Burhan Dayıoğlu', 'Burhan Dayıoğlu', 'Burhan Dayıoğlu', 'Burhan Dayıoğlu', 'BURHAN DAYIOĞLU', 'Burhan Dayıoğlu', 'Burhan Dayıoğlu', 'Burhan Dayıoğlu', '+90 (544) 591 7008', 'Kaş/ANTALYA', 'info@burhandayioglu.net', 'Web Developer', 'Burada Referans Başlığı olacak', 'Burada filo Başlığı olacak', 'Burada yorum Başlığı olacak', 'Burada yorum Başlığı olacak', 'hidgsdfcsaxd burası');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `filomuz`
--

DROP TABLE IF EXISTS `filomuz`;
CREATE TABLE IF NOT EXISTS `filomuz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resimyol` varchar(40) COLLATE utf8mb4_turkish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `filomuz`
--

INSERT INTO `filomuz` (`id`, `resimyol`) VALUES
(1, 'img/filo/1.jpg'),
(2, 'img/filo/2.jpg'),
(3, 'img/filo/3.jpg'),
(4, 'img/filo/4.jpg'),
(5, 'img/filo/5.jpg'),
(6, 'img/filo/6.jpg'),
(7, 'img/filo/7.jpg'),
(8, 'img/filo/8.jpg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hakkimizda`
--

DROP TABLE IF EXISTS `hakkimizda`;
CREATE TABLE IF NOT EXISTS `hakkimizda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `baslik` varchar(150) COLLATE utf8mb4_turkish_ci NOT NULL,
  `icerik` text COLLATE utf8mb4_turkish_ci NOT NULL,
  `resim` varchar(40) COLLATE utf8mb4_turkish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `hakkimizda`
--

INSERT INTO `hakkimizda` (`id`, `baslik`, `icerik`, `resim`) VALUES
(1, 'sfsdf', 'orem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyRYHTEGEG', 'img/hakkimiz.jpg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hizmetler`
--

DROP TABLE IF EXISTS `hizmetler`;
CREATE TABLE IF NOT EXISTS `hizmetler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `baslik` varchar(100) COLLATE utf8mb4_turkish_ci NOT NULL,
  `icerik` text COLLATE utf8mb4_turkish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `hizmetler`
--

INSERT INTO `hizmetler` (`id`, `baslik`, `icerik`) VALUES
(1, 'Başlık 1', 'İçerik  1İçerik  1İçerik  1İçerik  1İçerik  1İçerik  1İçerik  1'),
(2, ' başlık 55 ', 'icerirk 55 icerirk 55 icerirk 55 icerirk 55'),
(3, 'baslık 07', 'icerirk 5 icerirk 5 icerirk 6 icerirk 7');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `intro`
--

DROP TABLE IF EXISTS `intro`;
CREATE TABLE IF NOT EXISTS `intro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resimyol` varchar(40) COLLATE utf8mb4_turkish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `intro`
--

INSERT INTO `intro` (`id`, `resimyol`) VALUES
(2, 'img/carousel/2.jpg'),
(3, 'img/carousel/3.jpg'),
(4, 'img/carousel/4.jpg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `referanslar`
--

DROP TABLE IF EXISTS `referanslar`;
CREATE TABLE IF NOT EXISTS `referanslar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resimyol` varchar(40) COLLATE utf8mb4_turkish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `referanslar`
--

INSERT INTO `referanslar` (`id`, `resimyol`) VALUES
(1, 'img/referans/ref1.png'),
(2, 'img/referans/ref2.png'),
(3, 'img/referans/ref3.png'),
(4, 'img/referans/ref4.png'),
(5, 'img/referans/ref5.png'),
(6, 'img/referans/ref6.png'),
(7, 'img/referans/ref7.png'),
(8, 'img/referans/ref8.png');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `yonetim`
--

DROP TABLE IF EXISTS `yonetim`;
CREATE TABLE IF NOT EXISTS `yonetim` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kulad` varchar(60) COLLATE utf8_turkish_ci NOT NULL,
  `sifre` varchar(60) COLLATE utf8_turkish_ci NOT NULL,
  `aktif` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `yonetim`
--

INSERT INTO `yonetim` (`id`, `kulad`, `sifre`, `aktif`) VALUES
(1, 'olcay', 'ddcadbc8430c4e671849b81bafd7ab20', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `yorumlar`
--

DROP TABLE IF EXISTS `yorumlar`;
CREATE TABLE IF NOT EXISTS `yorumlar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `icerik` text COLLATE utf8_turkish_ci NOT NULL,
  `isim` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `yorumlar`
--

INSERT INTO `yorumlar` (`id`, `icerik`, `isim`) VALUES
(1, 'selamlar yorumlar yorumlar', 'ayhan'),
(2, 'selamlar yorumlar yorumlar', 'nurten');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
