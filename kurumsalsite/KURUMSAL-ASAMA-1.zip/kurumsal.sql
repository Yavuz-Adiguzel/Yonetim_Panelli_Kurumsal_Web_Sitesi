-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 29 Haz 2019, 13:01:43
-- Sunucu sürümü: 5.7.23
-- PHP Sürümü: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `ogrenci`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ayarlar`
--

DROP TABLE IF EXISTS `ayarlar`;
CREATE TABLE IF NOT EXISTS `ayarlar` (
  `id` int(11) NOT NULL,
  `title` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `metatitle` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `metadesc` text COLLATE utf8_turkish_ci NOT NULL,
  `metakey` text COLLATE utf8_turkish_ci NOT NULL,
  `metaauthor` varchar(40) COLLATE utf8_turkish_ci NOT NULL,
  `metaovner` varchar(40) COLLATE utf8_turkish_ci NOT NULL,
  `metacopy` varchar(40) COLLATE utf8_turkish_ci NOT NULL,
  `logoyazisi` varchar(40) COLLATE utf8_turkish_ci NOT NULL,
  `twit` varchar(70) COLLATE utf8_turkish_ci NOT NULL,
  `face` varchar(70) COLLATE utf8_turkish_ci NOT NULL,
  `insta` varchar(70) COLLATE utf8_turkish_ci NOT NULL,
  `telefonno` varchar(25) COLLATE utf8_turkish_ci NOT NULL,
  `adres` text COLLATE utf8_turkish_ci NOT NULL,
  `mailadres` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `slogan` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `referans_baslik` text COLLATE utf8_turkish_ci NOT NULL,
  `filo_baslik` text COLLATE utf8_turkish_ci NOT NULL,
  `yorum_baslik` text COLLATE utf8_turkish_ci NOT NULL,
  `iletisim_baslik` text COLLATE utf8_turkish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `ayarlar`
--

INSERT INTO `ayarlar` (`id`, `title`, `metatitle`, `metadesc`, `metakey`, `metaauthor`, `metaovner`, `metacopy`, `logoyazisi`, `twit`, `face`, `insta`, `telefonno`, `adres`, `mailadres`, `slogan`, `referans_baslik`, `filo_baslik`, `yorum_baslik`, `iletisim_baslik`) VALUES
(0, 'UDEMY Nakliyat', 'ogrenciNakliyat', 'Uluslararasi Tasimacilik hizmetleri', 'frigo, tir, uluslarasi tasimacilik, kamyon', 'Udemy Nakliyat San. Tic,. LTD. STI.', 'Udemy Nakliyat', '2019', 'UDEMY NAKLİYAT', 'https://www.twitter.com', 'https://www.youtube.com', 'instagram', '05554442211', 'dÜNYA', 'info@udemynakliyat.com', 'Nakliyatta Guven', 'Lorem ipsum referanlar', 'Lorem ipsum  filomuz Baslik dolor sit amet, consectetur adipisicing elit. Optio, consectetur accusamus', 'lorem ipsum yorumlar', 'Iletisim basligi');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `filo`
--

DROP TABLE IF EXISTS `filo`;
CREATE TABLE IF NOT EXISTS `filo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resimyol` varchar(40) COLLATE utf8_turkish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `filo`
--

INSERT INTO `filo` (`id`, `resimyol`) VALUES
(1, 'img/filo/1.jpg'),
(2, 'img/filo/2.jpg'),
(3, 'img/filo/3.jpg'),
(4, 'img/filo/4.jpg'),
(5, 'img/filo/5.jpg'),
(6, 'img/filo/6.jpg'),
(7, 'img/filo/7.jpg'),
(8, 'img/filo/8.jpg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hakkimizda`
--

DROP TABLE IF EXISTS `hakkimizda`;
CREATE TABLE IF NOT EXISTS `hakkimizda` (
  `id` int(11) NOT NULL,
  `baslik` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `icerik` text COLLATE utf8_turkish_ci NOT NULL,
  `resim` varchar(40) COLLATE utf8_turkish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `hakkimizda`
--

INSERT INTO `hakkimizda` (`id`, `baslik`, `icerik`, `resim`) VALUES
(0, 'Hakkimizda', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magnam illo cumque mollitia exercitationem quod id asperiores saepe explicabo nisi harum perferendis suscipit tempora dignissimos vitae, eum recusandae accusamus </h3> <h3>Lodio nostrum.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad saepe expedita aperiam porro vel debitis reprehenderit adipisci. Animi, dolorum consequatur natus corporis culpa ipsa. Sed architecto, recusandae? Nulla, laudantium, eum?', 'img/hakkimiz.jpg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hizmetlerimiz`
--

DROP TABLE IF EXISTS `hizmetlerimiz`;
CREATE TABLE IF NOT EXISTS `hizmetlerimiz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hizmetler_baslik` text COLLATE utf8_turkish_ci NOT NULL,
  `baslik1` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `icerik1` text COLLATE utf8_turkish_ci NOT NULL,
  `baslik2` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `icerik2` text COLLATE utf8_turkish_ci NOT NULL,
  `baslik3` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `icerik3` text COLLATE utf8_turkish_ci NOT NULL,
  `baslik4` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `icerik4` text COLLATE utf8_turkish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `hizmetlerimiz`
--

INSERT INTO `hizmetlerimiz` (`id`, `hizmetler_baslik`, `baslik1`, `icerik1`, `baslik2`, `icerik2`, `baslik3`, `icerik3`, `baslik4`, `icerik4`) VALUES
(1, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non odio eos porro itaque perspiciatis veritatis minima ipsa sit deserunt, quae numquam incidunt officiis aperiam possimus dolorum quia qui iusto id!lorem Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae quasi suscipit, aspernatur natus. Amet numquam quo excepturi deleniti consequuntur consectetur sit nihil architecto perspiciatis aliquid. Dolore a blanditiis incidunt totam?', 'Lorem Ipsum Baslik1', 'Lorem ipsum icerik 1 dolor sit amet, consectetur adipisicing elit. A esse, perspiciatis mollitia omnis id voluptatibus, sit quaerat, iure at perferendis tenetur suscipit eum saepe alias aliquid debitis totam voluptatum minus.', 'Lorem Ipsum Baslik2', 'Lorem ipsum icerik 2 dolor sit amet, consectetur adipisicing elit. A esse, perspiciatis mollitia omnis id voluptatibus, sit quaerat, iure at perferendis tenetur suscipit eum saepe alias aliquid debitis totam voluptatum minus.', 'Lorem Ipsum Baslik3', 'Lorem ipsum icerik 3 dolor sit amet, consectetur adipisicing elit. A esse, perspiciatis mollitia omnis id voluptatibus, sit quaerat, iure at perferendis tenetur suscipit eum saepe alias aliquid debitis totam voluptatum minus.', 'Lorem Ipsum Baslik4', 'Lorem ipsum icerik 4 dolor sit amet, consectetur adipisicing elit. A esse, perspiciatis mollitia omnis id voluptatibus, sit quaerat, iure at perferendis tenetur suscipit eum saepe alias aliquid debitis totam voluptatum minus.');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `intro`
--

DROP TABLE IF EXISTS `intro`;
CREATE TABLE IF NOT EXISTS `intro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resimyol` varchar(40) COLLATE utf8_turkish_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `intro`
--

INSERT INTO `intro` (`id`, `resimyol`) VALUES
(1, 'img/carousel/1.jpg'),
(2, 'img/carousel/2.jpg'),
(3, 'img/carousel/3.jpg'),
(4, 'img/carousel/4.jpg'),
(5, 'img/carousel/5.jpg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `referanslar`
--

DROP TABLE IF EXISTS `referanslar`;
CREATE TABLE IF NOT EXISTS `referanslar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resimyol` varchar(40) COLLATE utf8_turkish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `referanslar`
--

INSERT INTO `referanslar` (`id`, `resimyol`) VALUES
(1, 'img/referans/ref1.png'),
(2, 'img/referans/ref2.png'),
(3, 'img/referans/ref3.png'),
(4, 'img/referans/ref4.png'),
(5, 'img/referans/ref5.png'),
(6, 'img/referans/ref6.png'),
(7, 'img/referans/ref7.png'),
(8, 'img/referans/ref8.png');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `yonetim`
--

DROP TABLE IF EXISTS `yonetim`;
CREATE TABLE IF NOT EXISTS `yonetim` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kulad` varchar(60) COLLATE utf8_turkish_ci NOT NULL,
  `sifre` varchar(60) COLLATE utf8_turkish_ci NOT NULL,
  `aktif` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `yonetim`
--

INSERT INTO `yonetim` (`id`, `kulad`, `sifre`, `aktif`) VALUES
(1, 'olcay', 'ddcadbc8430c4e671849b81bafd7ab20', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `yorum`
--

DROP TABLE IF EXISTS `yorum`;
CREATE TABLE IF NOT EXISTS `yorum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `icerik` text COLLATE utf8_turkish_ci NOT NULL,
  `isim` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `yorum`
--

INSERT INTO `yorum` (`id`, `icerik`, `isim`) VALUES
(1, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus asperiores tenetur,', 'Yorum Yapan Firma 1'),
(2, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus asperiores tenetur,', 'Yorum Yapan Firma 2'),
(3, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus asperiores tenetur,', 'Yorum Yapan Firma 3'),
(4, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus asperiores tenetur,', 'Yorum Yapan Firma 4'),
(5, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus asperiores tenetur,', 'Yorum Yapan Firma 5');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
