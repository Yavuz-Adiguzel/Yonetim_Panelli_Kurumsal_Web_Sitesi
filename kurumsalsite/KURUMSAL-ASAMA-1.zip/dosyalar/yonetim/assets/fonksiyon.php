<?php 
ob_start ();
try {
	$baglanti=new PDO("mysql:host=localhost;dbname=kurumsal;charset=utf8","root","");
	$baglanti->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e) {
	die($e->getMessage());
}

class yonetim{
	function sorgum($vt,$sorgu,$tercih=0) {
		$al=$vt->prepare($sorgu);
		$al->execute();

		if ($tercih==1):
			return $al->fetch();
		elseif ($tercih==2):
			return $al->fetch(PDO::FETCH_ASSOC);

		endif;

		
	}
	function siteayar($baglanti) {
		$sonuc=self::sorgum($baglanti,"SELECT * from ayarlar",1);

		if ($_POST):
			//burada veri tabani islemleri
			$title=htmlspecialchars($_POST["title"]);
			$metatitle=htmlspecialchars($_POST["metatitle"]);
			$metadesc=htmlspecialchars($_POST["metadesc"]);
			$metakey=htmlspecialchars($_POST["metakey"]);
			$metaout=htmlspecialchars($_POST["metaout"]);
			$metaown=htmlspecialchars($_POST["metaown"]);
			$metacopy=htmlspecialchars($_POST["metacopy"]);
			$logoyazi=htmlspecialchars($_POST["logoyazi"]);
			$twit=htmlspecialchars($_POST["twit"]);
			$face=htmlspecialchars($_POST["face"]);
			$insta=htmlspecialchars($_POST["insta"]);
			$telno=htmlspecialchars($_POST["telno"]);
			$adres=htmlspecialchars($_POST["adres"]);
			$mailadres=htmlspecialchars($_POST["mailadres"]);
			$slogan=htmlspecialchars($_POST["slogan"]);
			$referans_baslik=htmlspecialchars($_POST["referans_baslik"]);
			$filo_baslik=htmlspecialchars($_POST["filo_baslik"]);
			$yorum_baslik=htmlspecialchars($_POST["yorum_baslik"]);
			$iletisim_baslik=htmlspecialchars($_POST["iletisim_baslik"]);
			// bu alanda bunlarin bos veya doluluk kontrolu yapilabilir

			$guncelleme=$baglanti->prepare("UPDATE ayarlar set title=?,metatitle=?,metadesc=?,metakey=?,metaauthor=?,metaovner=?,metacopy=?,logoyazisi=?,twit=?,face=?,insta=?,telefonno=?,adres=?,mailadres=?,slogan=?,referans_baslik=?,filo_baslik=?,yorum_baslik=?,iletisim_baslik=?");



			$guncelleme->bindParam(1,$title,PDO::PARAM_STR);
			$guncelleme->bindParam(2,$metatitle,PDO::PARAM_STR);
			$guncelleme->bindParam(3,$metadesc,PDO::PARAM_STR);
			$guncelleme->bindParam(4,$metakey,PDO::PARAM_STR);
			$guncelleme->bindParam(5,$metaout,PDO::PARAM_STR);
			$guncelleme->bindParam(6,$metaown,PDO::PARAM_STR);
			$guncelleme->bindParam(7,$metacopy,PDO::PARAM_STR);
			$guncelleme->bindParam(8,$logoyazi,PDO::PARAM_STR);
			$guncelleme->bindParam(9,$twit,PDO::PARAM_STR);
			$guncelleme->bindParam(10,$face,PDO::PARAM_STR);
			$guncelleme->bindParam(11,$insta,PDO::PARAM_STR);
			$guncelleme->bindParam(12,$telno,PDO::PARAM_STR);
			$guncelleme->bindParam(13,$adres,PDO::PARAM_STR);
			$guncelleme->bindParam(14,$mailadres,PDO::PARAM_STR);
			$guncelleme->bindParam(15,$slogan,PDO::PARAM_STR);
			$guncelleme->bindParam(16,$referans_baslik,PDO::PARAM_STR);
			$guncelleme->bindParam(17,$filo_baslik,PDO::PARAM_STR);
			$guncelleme->bindParam(18,$yorum_baslik,PDO::PARAM_STR);
			$guncelleme->bindParam(19,$iletisim_baslik,PDO::PARAM_STR);
			$guncelleme->execute();
			echo'<div class="alert alert-success mt-4" role="alert">
			<strong>Site Ayarları</strong>, başarılı bir şekilde güncellendi. </div>';
			header("refresh:2,url=control.php");

		else:
			?>

			<form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
				<div class="row ">
					<div class="col-lg-10 mx-auto mt-2 mb-4"><h5 class="text-info pull-left">Site ayarlari</h5></div> 
					<!--*******************TITLE****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">Site Başlığı</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="title" class="form-control" value="<?php echo $sonuc['title']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************TITLE****************-->
					<!--*******************META TITLE****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">Meta Başlığı</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="metatitle" class="form-control" value="<?php echo $sonuc['metatitle']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************TITLE****************-->
					<!--*******************META TITLE****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">Meta Açıklaması</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="metadesc" class="form-control" value="<?php echo $sonuc['metadesc']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************META TITLE****************-->
					<!--*******************META KEY****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">Anahtar Kelimeler</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="metakey" class="form-control" value="<?php echo $sonuc['metakey']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************META KEY****************-->
					<!--*******************Author****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">Yapımcı</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="metaout" class="form-control" value="<?php echo $sonuc['metaauthor']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************Author****************-->
					<!--*******************ovner****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">Site Sahibi</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="metaown" class="form-control" value="<?php echo $sonuc['metaovner']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************ovner****************-->
					<!--*******************Copywright****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">Copywright</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="metacopy" class="form-control" value="<?php echo $sonuc['metacopy']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************Copywright****************-->
					<!--*******************LOGO ****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">Logo</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="logoyazi" class="form-control" value="<?php echo $sonuc['logoyazisi']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************LOGO****************-->
					<!--*******************TWITTER****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">Twitter</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="twit" class="form-control" value="<?php echo $sonuc['twit']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************TWITTER****************-->
					<!--*******************FACEBOOK****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">Facebook</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="face" class="form-control" value="<?php echo $sonuc['face']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************FACEBOOK****************-->
					<!--*******************INSTAGRAM****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span class="siteayarfont">Instagram</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="insta" class="form-control" value="<?php echo $sonuc['insta']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************INSTAGRAM****************-->
					<!--*******************TELEFON****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">Telefon Numarası</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="telno" class="form-control" value="<?php echo $sonuc['telefonno']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************TELEFON****************-->
					<!--*******************ADRES****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">Adres</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="adres" class="form-control" value="<?php echo $sonuc['adres']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************TITLE****************-->
					<!--*******************EMAIL ADRESI****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">Email Adresi</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="mailadres" class="form-control" value="<?php echo $sonuc['mailadres']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************TITLE****************-->
					<!--*******************SLOGAN****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">Site Sloganı</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="slogan" class="form-control" value="<?php echo $sonuc['slogan']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************SLOGAN****************-->
					<!--*******************REFERANSLARIMIZ****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">Referanslarımız Başlığı</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="referans_baslik" class="form-control" value="<?php echo $sonuc['referans_baslik']; ?>" />
							</div>
						</div>
					</div>

					<!--*******************REFERANSLARIMIZ****************-->
					<!--*******************FILO****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">Filomuz Başlığı</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="filo_baslik" class="form-control" value="<?php echo $sonuc['filo_baslik']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************FILO****************-->
					<!--*******************YORUMLAR BASLIK****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">Yorumlar Başlığı</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="yorum_baslik" class="form-control" value="<?php echo $sonuc['yorum_baslik']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************YORUMLAR****************-->
					<!--*******************ILETISIM****************-->
					<div class="col-lg-8 mx-auto mt-2">
						<div class="row">
							<div class="col-lg-4 pt-3">
								<span id="siteayarfont">İletişim Başlığı</span>
							</div>
							<div class="col-lg-8 p-1">
								<input type="text" name="iletisim_baslik" class="form-control" value="<?php echo $sonuc['iletisim_baslik']; ?>" />
							</div>
						</div>
					</div>
					<!--*******************ILETISIM****************-->

					<div class="col-lg-8 mx-auto mt-2 border-bottom">
						<input type="submit" name="buton" class="btn btn-info m-1 pull-right" value="Güncelle"  />
					</div> 

				</div>

			</form>

			<?php



		endif;


	}
	function sifrele($veri) {
		return base64_encode(gzdeflate(gzcompress(serialize($veri))));

	}
	function coz($veri) {
		return unserialize(gzuncompress(gzinflate(base64_decode($veri))));

	}
	function kuladial($vt) {
		$cookid=$_COOKIE["kulbilgi"];
		$cozduk=self::coz($cookid);
		$sorgusonuc=self::sorgum($vt, "SELECT * from yonetim where id=$cozduk",1);
		return $sorgusonuc["kulad"];
	}
	//kullanici adini aldik


	function giriskontrol($kulad, $sifre, $vt) {

		 $sifrelihal=md5(sha1(md5($sifre)));	


		$sor=$vt->prepare("SELECT * from yonetim where kulad='$kulad' and sifre='$sifrelihal' ");
		$sor->execute();

		

		if($sor->rowCount()==0):
			echo '<div class="container-fluid bg-white ">
            <div class="alert alert-white  mt-5 col-md-5 mx-auto p-3 text-dark font-14 font-weight-bold"><img src="assets/images/loader.gif" width="90"alt="" />GİRİŞ BİLGİLERİ HATALI</div> 
            </div>';
			header("refresh:2, url=index.php");

		else:
			$gelendeger=$sor->fetch();
			
			$sor=$vt->prepare("UPDATE yonetim set aktif=1 where kulad='$kulad' and sifre='$sifrelihal'");
			$sor->execute();

			echo '
			<div class="container-fluid bg-white ">
            <div class="alert alert-white  mt-5 col-md-5 mx-auto p-3 text-dark font-14 font-weight-bold"><img src="assets/images/loader.gif" width="90"alt="" />KULLANICI ADI VE ŞİFRE DOĞRU...<br>Sayfa Yükleniyor Lütfen Bekleyiniz.</div> 
            </div>
            ';
			header("refresh:2, url=control.php");

			// cookie olusturmak
			 $id=self::sifrele($gelendeger["id"]);

			setcookie("kulbilgi", $id, time() + 60*60*24);


		endif;


	}
// GIRIS KONTROL BITIS

	function cikis($vt) {
		$cookid=$_COOKIE["kulbilgi"];
		/*
		Giris yapan kullanicinin bilgilerini teyid etmek icin db ye baglanabilirsin 
		o bilgiler ile saglama yaparak daha fazla kontrol yapabiliriz 

		*/
		$cozduk=self::coz($cookid);

	    self::sorgum($vt,"UPDATE yonetim set aktif=0 where id=$cozduk",0);
	    setcookie("kulbilgi",$cookid,time() -5);
	    echo '<div class="alert alert-info mt-5 col-md-5 mx-auto">BASARILI BIR SEKILDE CIKIS YAPTINIZ</div>';
	    header ("refresh:2, url=index.php");
	}

// CIKIS FONKSIYONU BITIS

	function kontrolet($sayfa) {

		if(isset($_COOKIE["kulbilgi"])) :

			if($sayfa=="ind") : header("Location:control.php"); endif;
		else:
			if($sayfa=="cot") : header("Location:index.php"); endif;
	    endif;

	}








}







?>
