<?php 
try {
	$baglanti=new PDO("mysql:host=localhost;dbname=kurumsal;charset=utf8","root","");
	$baglanti->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e) {
	die($e->getMessage());
}
class kurumsal {
	public $normaltitle,$metatitle,$metadesc,$metakey,$metaout,$metaown,$metacopy,$logoyazi,$twit,$face,$insta,$telno,$mailadres,$normaladres,$slogan,$referans_baslik,$filo_baslik,$yorum_baslik,$iletisim_baslik;

function __construct() { 


	try {
		$baglanti=new PDO("mysql:host=localhost;dbname=kurumsal;charset=utf8","root","");
		$baglanti->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	}catch(PDOException $e) {
		die($e->getMessage());
	}

	$ayarcek=$baglanti->prepare("SELECT * from ayarlar");
	$ayarcek->execute();
	$sorguson=$ayarcek->fetch();

	$this->normaltitle=$sorguson["title"];
	$this->metatitle=$sorguson["metatitle"];
	$this->metadesc=$sorguson["metadesc"];
	$this->metakey=$sorguson["metakey"];
	$this->metaout=$sorguson["metaauthor"];
	$this->metaown=$sorguson["metaovner"];
	$this->metacopy=$sorguson["metacopy"];
	$this->logoyazisi=$sorguson["logoyazisi"];
	$this->twit=$sorguson["twit"];
	$this->face=$sorguson["face"];
	$this->insta=$sorguson["insta"];
	$this->telno=$sorguson["telefonno"];
	$this->mailadres=$sorguson["mailadres"];
	$this->normaladres=$sorguson["adres"];
	$this->slogan=$sorguson["slogan"];
	$this->referans_baslik=$sorguson["referans_baslik"];
	$this->filo_baslik=$sorguson["filo_baslik"];
	$this->yorum_baslik=$sorguson["yorum_baslik"];
	$this->iletisim_baslik=$sorguson["iletisim_baslik"];



}

// Ayarlar tablosu son
/////////////////////////////////////////////////

function introbak($baglanti) {
	$introal=$baglanti->prepare("SELECT * from intro");
	$introal->execute();
	while ($sonucum=$introal->fetch(PDO::FETCH_ASSOC)):
		
		echo '<div class="item" style="background-image: url(' .$sonucum["resimyol"].');";></div>';
	endwhile;
}
// intro bitis 

///////////////////////////////////////////////////
function hakkimizda($baglanti) {
	$introal=$baglanti->prepare("SELECT * from hakkimizda");
	$introal->execute();
	$sonucum=$introal->fetch();

	echo ' <div class="row">
	<div class="col-lg-6 hakkimizda-img">
	<img src="'.$sonucum["resim"].'" alt="'.$sonucum["resim"].'-hakkinda" />
	</div>
	<div class=" col-lg-6 content">
	<h2>'.$sonucum["baslik"].'</h2>
	<h3>'.$sonucum["icerik"].'</h3>
	</div>
	</div>';

}
// Hakkimizda bitis

////////////////////////////////////////////////////

function hizmetlerimiz($baglanti) {
	$introal=$baglanti->prepare("SELECT * from hizmetlerimiz");
	$introal->execute();
	$sonucum=$introal->fetch();

	echo '  <div class="section-header">
	<h2>Hizmetlerimiz</h2>
	<p>'.$sonucum['hizmetler_baslik'].'</p>
	<div class="row">
	<div class="col-lg-6">
	<div class="box wow fadeInLeft">
	<div class="icon"><i class="fa fa-bar-chart"></i></div>
	<h4 class="title"><a href="#">'.$sonucum['baslik1'].'</a></h4>
	<p class="description">'.$sonucum['icerik1'].'</p>
	</div>
	</div>
	<div class="col-lg-6">
	<div class="box wow fadeInLeft">
	<div class="icon"><i class="fa fa-picture-o"></i></div>
	<h4 class="title"><a href="#">'.$sonucum['baslik2'].'</a></h4>
	<p class="description">'.$sonucum['icerik2'].'</p>
	</div>
	</div>
	<div class="col-lg-6">
	<div class="box wow fadeInRight">
	<div class="icon"><i class="fa fa-map"></i></div>
	<h4 class="title"><a href="#">'.$sonucum['baslik3'].'</a></h4>
	<p class="description">'.$sonucum['icerik3'].'</p>
	</div>
	</div>
	<div class="col-lg-6">
	<div class="box wow fadeInRight">
	<div class="icon"><i class="fa fa-shopping-bag"></i></div>
	<h4 class="title"><a href="#">'.$sonucum['baslik4'].'</a></h4>
	<p class="description">'.$sonucum['icerik4'].'</p>
	</div>
	</div>
	</div>
	</div> ';

}

//hizmetler bolumu son 
/////////////////////////////////////////////
function referans($baglanti) {
	$introal=$baglanti->prepare("SELECT * from referanslar");
	$introal->execute();
	echo ' <div class="section-header">
	<h2>Referanslarimiz</h2>
	<p>';echo $this->referans_baslik; echo ' </p>
	</div>
	<div class="owl-carousel clients-carousel">

	';

	while ($sonucum=$introal->fetch(PDO::FETCH_ASSOC)): 
		echo '<img src="'.$sonucum['resimyol'].'" alt="Udemy-nakliyat-referans" />';
	endwhile;
	echo '</div>';

}

//Referanslarimiz son
/////////////////////////////////////////////////////////////////////////

function filomuz($baglanti) {
	$introal=$baglanti->prepare("SELECT * from filo");
	$introal->execute();
	echo'
	<div class="container">
	<div class="section-header">
	<h2>Arac Filomuz</h2>
	<p>';echo $this->filo_baslik; echo' </p>
	</div>
	</div>
	<div class="container-fluid">
	<div class="row no-glutters">';

	while($sonucum=$introal->fetch(PDO::FETCH_ASSOC)):
		echo '<div class="col-lg-3 col-md-4">
		<div class="filo-item wowfadeInUp">
		<a href="'.$sonucum['resimyol'].'" class="filo-popup">
		<img src="'.$sonucum['resimyol'].'" alt="" />
		<div class="filo-overlay">
		</div>
		</a>
		</div>
		</div>
		';
	endwhile;
	echo'</div>
	</div>';
}
//Filomuz son 
/////////////////////////////////////////////

function yorumlar($baglanti) {
	$introal=$baglanti->prepare("SELECT * from yorum");
	$introal->execute();
	echo'<div class="section-header"><h2>Musteri yorumlari</h2>
	<p>';echo $this->yorum_baslik; echo'</p></div>
	<div class="owl-carousel testimonials-carousel">';

	while($sonucum=$introal->fetch(PDO::FETCH_ASSOC)):
		echo ' <div class="testimonial-item">
		<p><img src="img/sol.png" alt="" class="quote-sign-left" />'.$sonucum['icerik'].'
		<img src="img/sag.png" class="quote-sign-right" alt="" /></p>
		<img src="img/yorum.jpg" class="testimonial-img" alt="" />
		<h3>'.$sonucum['isim'].'</h3>
		</div>';
	endwhile;
	echo'</div>';
}

//Yorumlar son 
//////////////////////////////////////////////////////////










}









?>
