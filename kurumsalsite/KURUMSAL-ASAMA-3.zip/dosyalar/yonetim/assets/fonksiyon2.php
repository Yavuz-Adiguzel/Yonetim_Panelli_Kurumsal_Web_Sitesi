<?php 
include_once("fonksiyon.php");
class yonetim2 extends yonetim{
    /* fonksiyonları kes yapıstır
  index sayfasına dosya adı ve klssıdahil et
    case lerdeki classı değiştir
    <?php 
include_once("assets/fonksiyon.php");
include_once("assets/fonksiyon2.php");
$yonetim = new yonetim;
$yonetim2 = new yonetim2;
$yonetim->konrolet("ind");
?>
case "yonekle":
$yonetim2->yonekle($baglanti); 
break;
*/
}
    


?>               
        
       


  






